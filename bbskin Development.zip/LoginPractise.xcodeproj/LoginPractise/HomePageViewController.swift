//
//  HomePageViewController.swift
//  LoginPractise
//
//  Created by user142439 on 12/11/18.
//  Copyright © 2018 Dea Gjini. All rights reserved.
//

import UIKit

class HomePageViewController: UIViewController {

  
    @IBOutlet weak var userFullNameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func signOutButtonTapped(_ sender: Any) {
        
    }

    @IBAction func loadMemberProfileButtonTapped(_ sender: Any) {
        let defaults = UserDefaults.standard
        //let check = defaults.string(forKey: "FirstName")
        userFullNameLabel.text = (defaults.string(forKey: "FirstName")!) + " " + (defaults.string(forKey: "LastName")!)
       // userFullNameLabel.
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
