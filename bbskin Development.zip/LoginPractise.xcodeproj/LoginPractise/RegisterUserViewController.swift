//
//  RegisterUserViewController.swift
//  LoginPractise
//
//  Created by user142439 on 12/10/18.
//  Copyright © 2018 Dea Gjini. All rights reserved.
//

import UIKit

class RegisterUserViewController: UIViewController{
    

    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextFeild: UITextField!
    @IBOutlet weak var emailTestField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var reenterPasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func signUpButtonTapped(_ sender: Any) {
        //validate required fields are not empty
        if (firstNameTextField.text?.isEmpty)! ||
            (lastNameTextFeild.text?.isEmpty)! ||
            (emailTestField.text?.isEmpty)! ||
            (passwordTextField.text?.isEmpty)! ||
            (reenterPasswordTextField.text?.isEmpty)! {
            //display alert message and return
            displayMessage(userMessage: "All fields are required to fill in")
            return
        }
        
        //validate password
        if ((passwordTextField.text?.elementsEqual(reenterPasswordTextField.text!))! != true){
            //display alert message and return
            displayMessage(userMessage: "Please make sure passwords match")
            return
        }
        
//        //create activity indicator
//        let myActivityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)
//
//        //position activity indicator in the center of the main view
//        myActivityIndicator.center = view.center
//
//        //u can prevent actind from hiding when stopanimating() is called
//        myActivityIndicator.hidesWhenStopped = false
        
        //start it
        //myActivityIndicator.startAnimating()
        
        //view.addSubview(myActivityIndicator)
        
        
        let defaults = UserDefaults.standard
        defaults.set(firstNameTextField.text, forKey: "FirstName")
        defaults.set(lastNameTextFeild.text, forKey: "LastName")
        defaults.set(emailTestField.text, forKey: "Email")
        defaults.set(passwordTextField.text, forKey: "Password")
        // send HTTP request to register user ??? TF IS THIS
        //let myUrl = URL(String: ")
       // self.removeActivityIndicator(activityIndicator: myActivityIndicator)
        let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomePageViewController") as! HomePageViewController
        self.present(homeViewController, animated: true)
        
        
    }
    
    func displayMessage(userMessage:String) -> Void{
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Alert", message: userMessage, preferredStyle: .alert)

            let OKAction = UIAlertAction(title: "OK", style: .default){
                (action:UIAlertAction) in
                //trigger when ok button tapped
                print("OK button tapped")
                DispatchQueue.main.async {
                    self.dismiss(animated: true, completion: nil)
                }
            }
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
//
//    func removeActivityIndicator(activityIndicator: UIActivityIndicatorView){
//        DispatchQueue.main.async{
//            activityIndicator.stopAnimating()
//            activityIndicator.removeFromSuperview()
//        }
//    }
    

}
